﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim ChartArea1 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend1 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series1 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Dim Series3 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button_Home = New System.Windows.Forms.Button()
        Me.Button_bottom = New System.Windows.Forms.Button()
        Me.Button_top = New System.Windows.Forms.Button()
        Me.Button_left = New System.Windows.Forms.Button()
        Me.Button_right = New System.Windows.Forms.Button()
        Me.Button_adjustBrightness = New System.Windows.Forms.Button()
        Me.RadioButton_zoom_out = New System.Windows.Forms.RadioButton()
        Me.RadioButton_zoom_in = New System.Windows.Forms.RadioButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Button_Brightfield_Acquire = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.Pbar = New System.Windows.Forms.ProgressBar()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.CheckBoxLED = New System.Windows.Forms.CheckBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Button_GIMP = New System.Windows.Forms.Button()
        Me.TextBox_exposure = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBoxY = New System.Windows.Forms.TextBox()
        Me.TextBoxX = New System.Windows.Forms.TextBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton_Zprofile = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Preview = New System.Windows.Forms.RadioButton()
        Me.Button_Sedeen = New System.Windows.Forms.Button()
        Me.PictureBox_Preview = New System.Windows.Forms.PictureBox()
        Me.Button_Luigi = New System.Windows.Forms.Button()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.TabControl_Settings = New System.Windows.Forms.TabControl()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.CheckBox_PredictiveFocous = New System.Windows.Forms.CheckBox()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox_FOVY = New System.Windows.Forms.TextBox()
        Me.TextBox_FOVX = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TextBox_RichardScale = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button_TurnonGain = New System.Windows.Forms.Button()
        Me.Button_turnOffGain = New System.Windows.Forms.Button()
        Me.TextBox_BlueOffset = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBoxGC = New System.Windows.Forms.TextBox()
        Me.TextBoxGY = New System.Windows.Forms.TextBox()
        Me.TextBoxGain = New System.Windows.Forms.TextBox()
        Me.TextBox_GainB = New System.Windows.Forms.TextBox()
        Me.TextBox_GainG = New System.Windows.Forms.TextBox()
        Me.TextBox_GainR = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.LabelGC = New System.Windows.Forms.Label()
        Me.LabelGY = New System.Windows.Forms.Label()
        Me.LabelGain = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.HTML = New System.Windows.Forms.CheckBox()
        Me.SessionLocation = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.ConfirmAction = New System.Windows.Forms.Button()
        Me.ContinueSession = New System.Windows.Forms.RadioButton()
        Me.NewSession = New System.Windows.Forms.RadioButton()
        Me.SessionName = New System.Windows.Forms.Label()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Label_html_dir = New System.Windows.Forms.Label()
        Me.CheckBox_no_html = New System.Windows.Forms.CheckBox()
        Me.CheckBox_incognito = New System.Windows.Forms.CheckBox()
        Me.Button_experiment = New System.Windows.Forms.Button()
        Me.Button_OpenHtml = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.TextBox_PreviewFocus = New System.Windows.Forms.TextBox()
        Me.TextBox_PrevieEXp = New System.Windows.Forms.TextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.CheckBox_EDOF = New System.Windows.Forms.CheckBox()
        Me.PictureBox0 = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button_Scan2 = New System.Windows.Forms.Button()
        Me.ComboBox_Objetives = New System.Windows.Forms.ComboBox()
        Me.GroupBox3.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StatusStrip1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox_Preview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.TabControl_Settings.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox0, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button_Home)
        Me.GroupBox3.Controls.Add(Me.Button_bottom)
        Me.GroupBox3.Controls.Add(Me.Button_top)
        Me.GroupBox3.Controls.Add(Me.Button_left)
        Me.GroupBox3.Controls.Add(Me.Button_right)
        Me.GroupBox3.Location = New System.Drawing.Point(48, 287)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox3.Size = New System.Drawing.Size(220, 209)
        Me.GroupBox3.TabIndex = 106
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "XYZ"
        '
        'Button_Home
        '
        Me.Button_Home.BackgroundImage = CType(resources.GetObject("Button_Home.BackgroundImage"), System.Drawing.Image)
        Me.Button_Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_Home.ForeColor = System.Drawing.SystemColors.Control
        Me.Button_Home.Location = New System.Drawing.Point(76, 75)
        Me.Button_Home.Margin = New System.Windows.Forms.Padding(0)
        Me.Button_Home.Name = "Button_Home"
        Me.Button_Home.Size = New System.Drawing.Size(71, 58)
        Me.Button_Home.TabIndex = 40
        Me.Button_Home.UseVisualStyleBackColor = True
        '
        'Button_bottom
        '
        Me.Button_bottom.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button_bottom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_bottom.Image = CType(resources.GetObject("Button_bottom.Image"), System.Drawing.Image)
        Me.Button_bottom.Location = New System.Drawing.Point(83, 146)
        Me.Button_bottom.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_bottom.Name = "Button_bottom"
        Me.Button_bottom.Size = New System.Drawing.Size(53, 49)
        Me.Button_bottom.TabIndex = 39
        Me.Button_bottom.UseVisualStyleBackColor = True
        '
        'Button_top
        '
        Me.Button_top.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button_top.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_top.Image = CType(resources.GetObject("Button_top.Image"), System.Drawing.Image)
        Me.Button_top.Location = New System.Drawing.Point(81, 20)
        Me.Button_top.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_top.Name = "Button_top"
        Me.Button_top.Size = New System.Drawing.Size(53, 49)
        Me.Button_top.TabIndex = 38
        Me.Button_top.UseVisualStyleBackColor = True
        '
        'Button_left
        '
        Me.Button_left.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button_left.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_left.Image = CType(resources.GetObject("Button_left.Image"), System.Drawing.Image)
        Me.Button_left.Location = New System.Drawing.Point(11, 76)
        Me.Button_left.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_left.Name = "Button_left"
        Me.Button_left.Size = New System.Drawing.Size(53, 49)
        Me.Button_left.TabIndex = 37
        Me.Button_left.UseVisualStyleBackColor = True
        '
        'Button_right
        '
        Me.Button_right.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Button_right.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_right.Image = CType(resources.GetObject("Button_right.Image"), System.Drawing.Image)
        Me.Button_right.Location = New System.Drawing.Point(151, 76)
        Me.Button_right.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_right.Name = "Button_right"
        Me.Button_right.Size = New System.Drawing.Size(53, 49)
        Me.Button_right.TabIndex = 36
        Me.Button_right.UseVisualStyleBackColor = True
        '
        'Button_adjustBrightness
        '
        Me.Button_adjustBrightness.Location = New System.Drawing.Point(173, 12)
        Me.Button_adjustBrightness.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_adjustBrightness.Name = "Button_adjustBrightness"
        Me.Button_adjustBrightness.Size = New System.Drawing.Size(88, 36)
        Me.Button_adjustBrightness.TabIndex = 108
        Me.Button_adjustBrightness.Text = "Brightness"
        Me.Button_adjustBrightness.UseVisualStyleBackColor = True
        '
        'RadioButton_zoom_out
        '
        Me.RadioButton_zoom_out.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton_zoom_out.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_zoom_out.Location = New System.Drawing.Point(1329, 2)
        Me.RadioButton_zoom_out.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton_zoom_out.Name = "RadioButton_zoom_out"
        Me.RadioButton_zoom_out.Size = New System.Drawing.Size(57, 53)
        Me.RadioButton_zoom_out.TabIndex = 110
        Me.RadioButton_zoom_out.Text = "-"
        Me.RadioButton_zoom_out.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.RadioButton_zoom_out.UseVisualStyleBackColor = True
        '
        'RadioButton_zoom_in
        '
        Me.RadioButton_zoom_in.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton_zoom_in.AutoSize = True
        Me.RadioButton_zoom_in.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton_zoom_in.Location = New System.Drawing.Point(1277, 2)
        Me.RadioButton_zoom_in.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton_zoom_in.Name = "RadioButton_zoom_in"
        Me.RadioButton_zoom_in.Size = New System.Drawing.Size(51, 52)
        Me.RadioButton_zoom_in.TabIndex = 109
        Me.RadioButton_zoom_in.Text = "+"
        Me.RadioButton_zoom_in.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage10)
        Me.TabControl1.ItemSize = New System.Drawing.Size(71, 15)
        Me.TabControl1.Location = New System.Drawing.Point(0, 58)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(41, 1231)
        Me.TabControl1.TabIndex = 118
        '
        'TabPage3
        '
        Me.TabPage3.Location = New System.Drawing.Point(19, 4)
        Me.TabPage3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage3.Size = New System.Drawing.Size(18, 1223)
        Me.TabPage3.TabIndex = 1
        Me.TabPage3.Text = "White Dwarf"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Location = New System.Drawing.Point(19, 4)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(18, 1223)
        Me.TabPage4.TabIndex = 2
        Me.TabPage4.Text = "FiBi"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'TabPage10
        '
        Me.TabPage10.Location = New System.Drawing.Point(19, 4)
        Me.TabPage10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(18, 1223)
        Me.TabPage10.TabIndex = 3
        Me.TabPage10.Text = "EDOF"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Button_Brightfield_Acquire
        '
        Me.Button_Brightfield_Acquire.Location = New System.Drawing.Point(360, 12)
        Me.Button_Brightfield_Acquire.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_Brightfield_Acquire.Name = "Button_Brightfield_Acquire"
        Me.Button_Brightfield_Acquire.Size = New System.Drawing.Size(83, 36)
        Me.Button_Brightfield_Acquire.TabIndex = 3
        Me.Button_Brightfield_Acquire.Text = "Save"
        Me.Button_Brightfield_Acquire.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Chart1
        '
        Me.Chart1.BackColor = System.Drawing.Color.Transparent
        ChartArea1.AxisX.LabelStyle.Enabled = False
        ChartArea1.AxisX.MajorGrid.Enabled = False
        ChartArea1.AxisX.MajorTickMark.Enabled = False
        ChartArea1.AxisY.LabelStyle.Enabled = False
        ChartArea1.AxisY.MajorGrid.Enabled = False
        ChartArea1.BackColor = System.Drawing.Color.Transparent
        ChartArea1.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea1)
        Legend1.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend1)
        Me.Chart1.Location = New System.Drawing.Point(332, 322)
        Me.Chart1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Chart1.Name = "Chart1"
        Series1.ChartArea = "ChartArea1"
        Series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area
        Series1.IsVisibleInLegend = False
        Series1.Legend = "Legend1"
        Series1.Name = "Series1"
        Series2.ChartArea = "ChartArea1"
        Series2.IsVisibleInLegend = False
        Series2.Legend = "Legend1"
        Series2.Name = "Series2"
        Series3.ChartArea = "ChartArea1"
        Series3.IsVisibleInLegend = False
        Series3.Legend = "Legend1"
        Series3.Name = "Series3"
        Me.Chart1.Series.Add(Series1)
        Me.Chart1.Series.Add(Series2)
        Me.Chart1.Series.Add(Series3)
        Me.Chart1.Size = New System.Drawing.Size(423, 150)
        Me.Chart1.TabIndex = 120
        Me.Chart1.Text = "Chart1"
        '
        'Pbar
        '
        Me.Pbar.Location = New System.Drawing.Point(744, 14)
        Me.Pbar.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Pbar.Name = "Pbar"
        Me.Pbar.Size = New System.Drawing.Size(525, 36)
        Me.Pbar.TabIndex = 126
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 820)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 19, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(1844, 26)
        Me.StatusStrip1.TabIndex = 129
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(153, 20)
        Me.ToolStripStatusLabel1.Text = "ToolStripStatusLabel1"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(153, 20)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(153, 20)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1797, 12)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 36)
        Me.Button1.TabIndex = 130
        Me.Button1.Text = "Clear"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(1672, 14)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(117, 36)
        Me.Button6.TabIndex = 137
        Me.Button6.Text = "Load Sample"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'CheckBoxLED
        '
        Me.CheckBoxLED.AutoSize = True
        Me.CheckBoxLED.Location = New System.Drawing.Point(1397, 21)
        Me.CheckBoxLED.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBoxLED.Name = "CheckBoxLED"
        Me.CheckBoxLED.Size = New System.Drawing.Size(55, 20)
        Me.CheckBoxLED.TabIndex = 138
        Me.CheckBoxLED.Text = "LED"
        Me.CheckBoxLED.UseVisualStyleBackColor = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 16
        Me.ListBox1.Location = New System.Drawing.Point(763, 97)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(203, 308)
        Me.ListBox1.TabIndex = 139
        '
        'Button_GIMP
        '
        Me.Button_GIMP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_GIMP.Location = New System.Drawing.Point(724, 480)
        Me.Button_GIMP.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_GIMP.Name = "Button_GIMP"
        Me.Button_GIMP.Size = New System.Drawing.Size(67, 62)
        Me.Button_GIMP.TabIndex = 140
        Me.Button_GIMP.Text = "GIMP"
        Me.Button_GIMP.UseVisualStyleBackColor = True
        Me.Button_GIMP.Visible = False
        '
        'TextBox_exposure
        '
        Me.TextBox_exposure.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_exposure.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_exposure.Location = New System.Drawing.Point(92, 15)
        Me.TextBox_exposure.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_exposure.Name = "TextBox_exposure"
        Me.TextBox_exposure.Size = New System.Drawing.Size(73, 30)
        Me.TextBox_exposure.TabIndex = 143
        Me.TextBox_exposure.Text = "300"
        Me.TextBox_exposure.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 22)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 16)
        Me.Label9.TabIndex = 144
        Me.Label9.Text = "Exposure"
        '
        'TextBoxY
        '
        Me.TextBoxY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxY.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxY.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBoxY.Location = New System.Drawing.Point(696, 18)
        Me.TextBoxY.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBoxY.Name = "TextBoxY"
        Me.TextBoxY.Size = New System.Drawing.Size(40, 25)
        Me.TextBoxY.TabIndex = 90
        Me.TextBoxY.Text = "5"
        Me.TextBoxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxX
        '
        Me.TextBoxX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxX.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxX.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBoxX.Location = New System.Drawing.Point(648, 18)
        Me.TextBoxX.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBoxX.Name = "TextBoxX"
        Me.TextBoxX.Size = New System.Drawing.Size(40, 25)
        Me.TextBoxX.TabIndex = 89
        Me.TextBoxX.Text = "5"
        Me.TextBoxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Timer1
        '
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Location = New System.Drawing.Point(1468, 58)
        Me.TabControl2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(1024, 1202)
        Me.TabControl2.TabIndex = 148
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox2)
        Me.TabPage6.Controls.Add(Me.Button_Sedeen)
        Me.TabPage6.Controls.Add(Me.PictureBox_Preview)
        Me.TabPage6.Controls.Add(Me.ListBox1)
        Me.TabPage6.Controls.Add(Me.Button_Luigi)
        Me.TabPage6.Controls.Add(Me.Button_GIMP)
        Me.TabPage6.Controls.Add(Me.GroupBox3)
        Me.TabPage6.Controls.Add(Me.Chart1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage6.Size = New System.Drawing.Size(1016, 1173)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "Preview"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton_Zprofile)
        Me.GroupBox2.Controls.Add(Me.RadioButton_Preview)
        Me.GroupBox2.Location = New System.Drawing.Point(21, 31)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(173, 38)
        Me.GroupBox2.TabIndex = 148
        Me.GroupBox2.TabStop = False
        '
        'RadioButton_Zprofile
        '
        Me.RadioButton_Zprofile.AutoSize = True
        Me.RadioButton_Zprofile.Location = New System.Drawing.Point(85, 11)
        Me.RadioButton_Zprofile.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton_Zprofile.Name = "RadioButton_Zprofile"
        Me.RadioButton_Zprofile.Size = New System.Drawing.Size(66, 20)
        Me.RadioButton_Zprofile.TabIndex = 1
        Me.RadioButton_Zprofile.Text = "Profile"
        Me.RadioButton_Zprofile.UseVisualStyleBackColor = True
        '
        'RadioButton_Preview
        '
        Me.RadioButton_Preview.AutoSize = True
        Me.RadioButton_Preview.Checked = True
        Me.RadioButton_Preview.Location = New System.Drawing.Point(5, 11)
        Me.RadioButton_Preview.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton_Preview.Name = "RadioButton_Preview"
        Me.RadioButton_Preview.Size = New System.Drawing.Size(66, 20)
        Me.RadioButton_Preview.TabIndex = 0
        Me.RadioButton_Preview.TabStop = True
        Me.RadioButton_Preview.Text = "Image"
        Me.RadioButton_Preview.UseVisualStyleBackColor = True
        '
        'Button_Sedeen
        '
        Me.Button_Sedeen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Sedeen.Location = New System.Drawing.Point(763, 609)
        Me.Button_Sedeen.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_Sedeen.Name = "Button_Sedeen"
        Me.Button_Sedeen.Size = New System.Drawing.Size(67, 62)
        Me.Button_Sedeen.TabIndex = 147
        Me.Button_Sedeen.Text = "Sedeen"
        Me.Button_Sedeen.UseVisualStyleBackColor = True
        Me.Button_Sedeen.Visible = False
        '
        'PictureBox_Preview
        '
        Me.PictureBox_Preview.BackColor = System.Drawing.Color.Black
        Me.PictureBox_Preview.Location = New System.Drawing.Point(21, 97)
        Me.PictureBox_Preview.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox_Preview.Name = "PictureBox_Preview"
        Me.PictureBox_Preview.Size = New System.Drawing.Size(733, 165)
        Me.PictureBox_Preview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_Preview.TabIndex = 124
        Me.PictureBox_Preview.TabStop = False
        '
        'Button_Luigi
        '
        Me.Button_Luigi.BackgroundImage = CType(resources.GetObject("Button_Luigi.BackgroundImage"), System.Drawing.Image)
        Me.Button_Luigi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button_Luigi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Luigi.Location = New System.Drawing.Point(799, 480)
        Me.Button_Luigi.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_Luigi.Name = "Button_Luigi"
        Me.Button_Luigi.Size = New System.Drawing.Size(67, 62)
        Me.Button_Luigi.TabIndex = 146
        Me.Button_Luigi.UseVisualStyleBackColor = True
        Me.Button_Luigi.Visible = False
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.TabControl_Settings)
        Me.TabPage7.Location = New System.Drawing.Point(4, 25)
        Me.TabPage7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage7.Size = New System.Drawing.Size(1016, 1173)
        Me.TabPage7.TabIndex = 1
        Me.TabPage7.Text = "Settings"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'TabControl_Settings
        '
        Me.TabControl_Settings.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.TabControl_Settings.Controls.Add(Me.TabPage13)
        Me.TabControl_Settings.Controls.Add(Me.TabPage8)
        Me.TabControl_Settings.Controls.Add(Me.TabPage1)
        Me.TabControl_Settings.Controls.Add(Me.TabPage12)
        Me.TabControl_Settings.Controls.Add(Me.TabPage2)
        Me.TabControl_Settings.Controls.Add(Me.TabPage5)
        Me.TabControl_Settings.Controls.Add(Me.TabPage9)
        Me.TabControl_Settings.Controls.Add(Me.TabPage11)
        Me.TabControl_Settings.Location = New System.Drawing.Point(35, 146)
        Me.TabControl_Settings.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabControl_Settings.Name = "TabControl_Settings"
        Me.TabControl_Settings.SelectedIndex = 0
        Me.TabControl_Settings.Size = New System.Drawing.Size(927, 459)
        Me.TabControl_Settings.TabIndex = 111
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage13.Controls.Add(Me.CheckBox_PredictiveFocous)
        Me.TabPage13.Controls.Add(Me.Button20)
        Me.TabPage13.Controls.Add(Me.Button21)
        Me.TabPage13.Controls.Add(Me.Button15)
        Me.TabPage13.Controls.Add(Me.Button14)
        Me.TabPage13.Controls.Add(Me.Label16)
        Me.TabPage13.Controls.Add(Me.TextBox16)
        Me.TabPage13.Controls.Add(Me.TextBox_FOVY)
        Me.TabPage13.Controls.Add(Me.TextBox_FOVX)
        Me.TabPage13.Controls.Add(Me.TextBox10)
        Me.TabPage13.Controls.Add(Me.TextBox11)
        Me.TabPage13.Controls.Add(Me.TextBox12)
        Me.TabPage13.Controls.Add(Me.TextBox7)
        Me.TabPage13.Controls.Add(Me.TextBox8)
        Me.TabPage13.Controls.Add(Me.TextBox9)
        Me.TabPage13.Controls.Add(Me.TextBox4)
        Me.TabPage13.Controls.Add(Me.TextBox5)
        Me.TabPage13.Controls.Add(Me.TextBox6)
        Me.TabPage13.Controls.Add(Me.TextBox3)
        Me.TabPage13.Controls.Add(Me.TextBox2)
        Me.TabPage13.Controls.Add(Me.TextBox1)
        Me.TabPage13.Controls.Add(Me.Button10)
        Me.TabPage13.Controls.Add(Me.Button5)
        Me.TabPage13.Controls.Add(Me.Label15)
        Me.TabPage13.Controls.Add(Me.Label4)
        Me.TabPage13.Controls.Add(Me.Label8)
        Me.TabPage13.Controls.Add(Me.Label7)
        Me.TabPage13.Controls.Add(Me.Label6)
        Me.TabPage13.Controls.Add(Me.Label5)
        Me.TabPage13.Controls.Add(Me.Button7)
        Me.TabPage13.Controls.Add(Me.Button9)
        Me.TabPage13.Controls.Add(Me.Label3)
        Me.TabPage13.Controls.Add(Me.Label2)
        Me.TabPage13.Controls.Add(Me.Label1)
        Me.TabPage13.Location = New System.Drawing.Point(4, 28)
        Me.TabPage13.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(919, 427)
        Me.TabPage13.TabIndex = 3
        Me.TabPage13.Text = "Stage"
        '
        'CheckBox_PredictiveFocous
        '
        Me.CheckBox_PredictiveFocous.AutoSize = True
        Me.CheckBox_PredictiveFocous.Location = New System.Drawing.Point(559, 238)
        Me.CheckBox_PredictiveFocous.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox_PredictiveFocous.Name = "CheckBox_PredictiveFocous"
        Me.CheckBox_PredictiveFocous.Size = New System.Drawing.Size(137, 20)
        Me.CheckBox_PredictiveFocous.TabIndex = 158
        Me.CheckBox_PredictiveFocous.Text = "Predictive Focous"
        Me.CheckBox_PredictiveFocous.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(153, 300)
        Me.Button20.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(100, 28)
        Me.Button20.TabIndex = 69
        Me.Button20.Text = "Set Ymax"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(45, 300)
        Me.Button21.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(100, 28)
        Me.Button21.TabIndex = 68
        Me.Button21.Text = "Set Xmax"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(153, 265)
        Me.Button15.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(100, 28)
        Me.Button15.TabIndex = 67
        Me.Button15.Text = "Set Ymin"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(45, 265)
        Me.Button14.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(100, 28)
        Me.Button14.TabIndex = 66
        Me.Button14.Text = "Set Xmin"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(555, 187)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(92, 20)
        Me.Label16.TabIndex = 65
        Me.Label16.Text = "Cropp Size"
        '
        'TextBox16
        '
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox16.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox16.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox16.Location = New System.Drawing.Point(692, 180)
        Me.TextBox16.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(75, 25)
        Me.TextBox16.TabIndex = 64
        Me.TextBox16.Text = "400"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_FOVY
        '
        Me.TextBox_FOVY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_FOVY.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_FOVY.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_FOVY.Location = New System.Drawing.Point(625, 85)
        Me.TextBox_FOVY.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_FOVY.Name = "TextBox_FOVY"
        Me.TextBox_FOVY.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_FOVY.TabIndex = 61
        Me.TextBox_FOVY.Text = "0.1"
        Me.TextBox_FOVY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_FOVX
        '
        Me.TextBox_FOVX.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_FOVX.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_FOVX.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_FOVX.Location = New System.Drawing.Point(624, 52)
        Me.TextBox_FOVX.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_FOVX.Name = "TextBox_FOVX"
        Me.TextBox_FOVX.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_FOVX.TabIndex = 59
        Me.TextBox_FOVX.Text = "0.1"
        Me.TextBox_FOVX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox10.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox10.Location = New System.Drawing.Point(408, 54)
        Me.TextBox10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(75, 25)
        Me.TextBox10.TabIndex = 56
        Me.TextBox10.Text = "3000"
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox11.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox11.Location = New System.Drawing.Point(408, 97)
        Me.TextBox11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(75, 25)
        Me.TextBox11.TabIndex = 55
        Me.TextBox11.Text = "3000"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox12.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox12.Location = New System.Drawing.Point(408, 142)
        Me.TextBox12.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(75, 25)
        Me.TextBox12.TabIndex = 54
        Me.TextBox12.Text = "1000"
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox7
        '
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox7.Location = New System.Drawing.Point(325, 54)
        Me.TextBox7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(75, 25)
        Me.TextBox7.TabIndex = 52
        Me.TextBox7.Text = "65"
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox8
        '
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox8.Location = New System.Drawing.Point(325, 97)
        Me.TextBox8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(75, 25)
        Me.TextBox8.TabIndex = 51
        Me.TextBox8.Text = "65"
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox9.Location = New System.Drawing.Point(325, 142)
        Me.TextBox9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(75, 25)
        Me.TextBox9.TabIndex = 50
        Me.TextBox9.Text = "48"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox4
        '
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox4.Location = New System.Drawing.Point(207, 54)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(75, 25)
        Me.TextBox4.TabIndex = 42
        Me.TextBox4.Text = "0.1"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox5
        '
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox5.Location = New System.Drawing.Point(207, 97)
        Me.TextBox5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(75, 25)
        Me.TextBox5.TabIndex = 41
        Me.TextBox5.Text = "0.1"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox6
        '
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox6.Location = New System.Drawing.Point(207, 142)
        Me.TextBox6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(75, 25)
        Me.TextBox6.TabIndex = 40
        Me.TextBox6.Text = "0.1"
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox3.Location = New System.Drawing.Point(113, 142)
        Me.TextBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(75, 25)
        Me.TextBox3.TabIndex = 37
        Me.TextBox3.Text = "0.1"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox2.Location = New System.Drawing.Point(113, 97)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(75, 25)
        Me.TextBox2.TabIndex = 36
        Me.TextBox2.Text = "0.1"
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox1.Location = New System.Drawing.Point(113, 54)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(75, 25)
        Me.TextBox1.TabIndex = 35
        Me.TextBox1.Text = "0.1"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(667, 138)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(100, 28)
        Me.Button10.TabIndex = 63
        Me.Button10.Text = "Done!"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(559, 138)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(100, 28)
        Me.Button5.TabIndex = 62
        Me.Button5.Text = "Test FOV"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(555, 85)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(58, 20)
        Me.Label15.TabIndex = 60
        Me.Label15.Text = "FOV Y"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(555, 54)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 20)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "FOV X"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(404, 23)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 16)
        Me.Label8.TabIndex = 57
        Me.Label8.Text = "Acceleration"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(321, 23)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 16)
        Me.Label7.TabIndex = 53
        Me.Label7.Text = "Speed"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(203, 23)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 16)
        Me.Label6.TabIndex = 49
        Me.Label6.Text = "Absolute"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(109, 23)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 16)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Relative"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(27, 178)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(161, 28)
        Me.Button7.TabIndex = 47
        Me.Button7.Text = "Go Zero"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(196, 178)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(161, 28)
        Me.Button9.TabIndex = 38
        Me.Button9.Text = "Calibrate Z offset"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(41, 146)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Z (um):"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(41, 100)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 20)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Y (mm):"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(41, 54)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 20)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "X (mm):"
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.Label21)
        Me.TabPage8.Controls.Add(Me.Button25)
        Me.TabPage8.Controls.Add(Me.Button24)
        Me.TabPage8.Controls.Add(Me.Button23)
        Me.TabPage8.Controls.Add(Me.Label18)
        Me.TabPage8.Controls.Add(Me.Label19)
        Me.TabPage8.Controls.Add(Me.TextBox17)
        Me.TabPage8.Controls.Add(Me.TextBox18)
        Me.TabPage8.Controls.Add(Me.Label20)
        Me.TabPage8.Location = New System.Drawing.Point(4, 28)
        Me.TabPage8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(919, 427)
        Me.TabPage8.TabIndex = 8
        Me.TabPage8.Text = "Piezo"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(499, 159)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(55, 16)
        Me.Label21.TabIndex = 58
        Me.Label21.Text = "Label21"
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(361, 148)
        Me.Button25.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(100, 28)
        Me.Button25.TabIndex = 57
        Me.Button25.Text = "Calibrate"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(469, 112)
        Me.Button24.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(100, 28)
        Me.Button24.TabIndex = 56
        Me.Button24.Text = "Done!"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(361, 112)
        Me.Button23.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(100, 28)
        Me.Button23.TabIndex = 55
        Me.Button23.Text = "Evaluate"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(223, 82)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(60, 16)
        Me.Label18.TabIndex = 54
        Me.Label18.Text = "Absolute"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(147, 82)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(57, 16)
        Me.Label19.TabIndex = 53
        Me.Label19.Text = "Relative"
        '
        'TextBox17
        '
        Me.TextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox17.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox17.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox17.Location = New System.Drawing.Point(227, 116)
        Me.TextBox17.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(75, 25)
        Me.TextBox17.TabIndex = 52
        Me.TextBox17.Text = "0.1"
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox18
        '
        Me.TextBox18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox18.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox18.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox18.Location = New System.Drawing.Point(133, 116)
        Me.TextBox18.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(75, 25)
        Me.TextBox18.TabIndex = 51
        Me.TextBox18.Text = "0.1"
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(61, 121)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(63, 20)
        Me.Label20.TabIndex = 50
        Me.Label20.Text = "Z (um):"
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage1.Controls.Add(Me.TextBox_RichardScale)
        Me.TabPage1.Controls.Add(Me.Label31)
        Me.TabPage1.Controls.Add(Me.Button29)
        Me.TabPage1.Controls.Add(Me.Button16)
        Me.TabPage1.Controls.Add(Me.Button_TurnonGain)
        Me.TabPage1.Controls.Add(Me.Button_turnOffGain)
        Me.TabPage1.Controls.Add(Me.TextBox_BlueOffset)
        Me.TabPage1.Controls.Add(Me.TextBox13)
        Me.TabPage1.Controls.Add(Me.TextBox14)
        Me.TabPage1.Controls.Add(Me.TextBox15)
        Me.TabPage1.Controls.Add(Me.TextBoxGC)
        Me.TabPage1.Controls.Add(Me.TextBoxGY)
        Me.TabPage1.Controls.Add(Me.TextBoxGain)
        Me.TabPage1.Controls.Add(Me.TextBox_GainB)
        Me.TabPage1.Controls.Add(Me.TextBox_GainG)
        Me.TabPage1.Controls.Add(Me.TextBox_GainR)
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.Button32)
        Me.TabPage1.Controls.Add(Me.Button11)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.LabelGC)
        Me.TabPage1.Controls.Add(Me.LabelGY)
        Me.TabPage1.Controls.Add(Me.LabelGain)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Location = New System.Drawing.Point(4, 28)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(919, 427)
        Me.TabPage1.TabIndex = 5
        Me.TabPage1.Text = "Camera"
        '
        'TextBox_RichardScale
        '
        Me.TextBox_RichardScale.AcceptsReturn = True
        Me.TextBox_RichardScale.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_RichardScale.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_RichardScale.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_RichardScale.Location = New System.Drawing.Point(704, 98)
        Me.TextBox_RichardScale.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_RichardScale.Name = "TextBox_RichardScale"
        Me.TextBox_RichardScale.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_RichardScale.TabIndex = 154
        Me.TextBox_RichardScale.Text = "5"
        Me.TextBox_RichardScale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(572, 98)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(114, 20)
        Me.Label31.TabIndex = 153
        Me.Label31.Text = "Richard Scale"
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(659, 316)
        Me.Button29.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(177, 28)
        Me.Button29.TabIndex = 152
        Me.Button29.Text = "Test camera Frame rate"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(473, 316)
        Me.Button16.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(177, 28)
        Me.Button16.TabIndex = 151
        Me.Button16.Text = "Calibrate"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Button_TurnonGain
        '
        Me.Button_TurnonGain.Location = New System.Drawing.Point(473, 178)
        Me.Button_TurnonGain.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_TurnonGain.Name = "Button_TurnonGain"
        Me.Button_TurnonGain.Size = New System.Drawing.Size(172, 28)
        Me.Button_TurnonGain.TabIndex = 150
        Me.Button_TurnonGain.Text = "Turn on Gain"
        Me.Button_TurnonGain.UseVisualStyleBackColor = True
        '
        'Button_turnOffGain
        '
        Me.Button_turnOffGain.Location = New System.Drawing.Point(473, 214)
        Me.Button_turnOffGain.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_turnOffGain.Name = "Button_turnOffGain"
        Me.Button_turnOffGain.Size = New System.Drawing.Size(172, 28)
        Me.Button_turnOffGain.TabIndex = 149
        Me.Button_turnOffGain.Text = "Turn off Gain"
        Me.Button_turnOffGain.UseVisualStyleBackColor = True
        '
        'TextBox_BlueOffset
        '
        Me.TextBox_BlueOffset.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_BlueOffset.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_BlueOffset.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_BlueOffset.Location = New System.Drawing.Point(704, 48)
        Me.TextBox_BlueOffset.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_BlueOffset.Name = "TextBox_BlueOffset"
        Me.TextBox_BlueOffset.ShortcutsEnabled = False
        Me.TextBox_BlueOffset.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_BlueOffset.TabIndex = 148
        Me.TextBox_BlueOffset.Text = "0"
        Me.TextBox_BlueOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox13.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox13.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox13.Location = New System.Drawing.Point(488, 138)
        Me.TextBox13.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(75, 25)
        Me.TextBox13.TabIndex = 141
        Me.TextBox13.Text = "1"
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox14
        '
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox14.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox14.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox14.Location = New System.Drawing.Point(488, 94)
        Me.TextBox14.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(75, 25)
        Me.TextBox14.TabIndex = 140
        Me.TextBox14.Text = "1"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox15.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox15.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox15.Location = New System.Drawing.Point(488, 50)
        Me.TextBox15.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(75, 25)
        Me.TextBox15.TabIndex = 139
        Me.TextBox15.Text = "1"
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxGC
        '
        Me.TextBoxGC.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxGC.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxGC.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBoxGC.Location = New System.Drawing.Point(297, 135)
        Me.TextBoxGC.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBoxGC.Name = "TextBoxGC"
        Me.TextBoxGC.Size = New System.Drawing.Size(75, 25)
        Me.TextBoxGC.TabIndex = 49
        Me.TextBoxGC.Text = "0"
        Me.TextBoxGC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxGY
        '
        Me.TextBoxGY.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxGY.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxGY.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBoxGY.Location = New System.Drawing.Point(297, 91)
        Me.TextBoxGY.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBoxGY.Name = "TextBoxGY"
        Me.TextBoxGY.Size = New System.Drawing.Size(75, 25)
        Me.TextBoxGY.TabIndex = 48
        Me.TextBoxGY.Text = "1"
        Me.TextBoxGY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBoxGain
        '
        Me.TextBoxGain.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxGain.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxGain.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBoxGain.Location = New System.Drawing.Point(297, 48)
        Me.TextBoxGain.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBoxGain.Name = "TextBoxGain"
        Me.TextBoxGain.Size = New System.Drawing.Size(75, 25)
        Me.TextBoxGain.TabIndex = 47
        Me.TextBoxGain.Text = "10"
        Me.TextBoxGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_GainB
        '
        Me.TextBox_GainB.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_GainB.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GainB.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_GainB.Location = New System.Drawing.Point(119, 135)
        Me.TextBox_GainB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_GainB.Name = "TextBox_GainB"
        Me.TextBox_GainB.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_GainB.TabIndex = 43
        Me.TextBox_GainB.Text = "1"
        Me.TextBox_GainB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_GainG
        '
        Me.TextBox_GainG.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_GainG.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GainG.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_GainG.Location = New System.Drawing.Point(119, 91)
        Me.TextBox_GainG.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_GainG.Name = "TextBox_GainG"
        Me.TextBox_GainG.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_GainG.TabIndex = 42
        Me.TextBox_GainG.Text = "1"
        Me.TextBox_GainG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_GainR
        '
        Me.TextBox_GainR.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_GainR.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_GainR.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox_GainR.Location = New System.Drawing.Point(119, 48)
        Me.TextBox_GainR.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_GainR.Name = "TextBox_GainR"
        Me.TextBox_GainR.Size = New System.Drawing.Size(75, 25)
        Me.TextBox_GainR.TabIndex = 41
        Me.TextBox_GainR.Text = "1"
        Me.TextBox_GainR.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(571, 53)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(89, 20)
        Me.Label27.TabIndex = 147
        Me.Label27.Text = "BlueOffset"
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(257, 214)
        Me.Button32.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(172, 28)
        Me.Button32.TabIndex = 146
        Me.Button32.Text = "Turn off FlatField"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(257, 178)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(172, 28)
        Me.Button11.TabIndex = 145
        Me.Button11.Text = "Turn on FlatField"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(404, 145)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 20)
        Me.Label10.TabIndex = 144
        Me.Label10.Text = "Matrix 22"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(404, 98)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 20)
        Me.Label11.TabIndex = 143
        Me.Label11.Text = "Matrix 11"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(404, 53)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 20)
        Me.Label12.TabIndex = 142
        Me.Label12.Text = "Matrix 00"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(51, 178)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(177, 28)
        Me.Button3.TabIndex = 137
        Me.Button3.Text = "Acquire FlatField"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'LabelGC
        '
        Me.LabelGC.AutoSize = True
        Me.LabelGC.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGC.Location = New System.Drawing.Point(203, 140)
        Me.LabelGC.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelGC.Name = "LabelGC"
        Me.LabelGC.Size = New System.Drawing.Size(80, 20)
        Me.LabelGC.TabIndex = 46
        Me.LabelGC.Text = "GammaC"
        '
        'LabelGY
        '
        Me.LabelGY.AutoSize = True
        Me.LabelGY.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGY.Location = New System.Drawing.Point(203, 94)
        Me.LabelGY.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelGY.Name = "LabelGY"
        Me.LabelGY.Size = New System.Drawing.Size(78, 20)
        Me.LabelGY.TabIndex = 45
        Me.LabelGY.Text = "GammaY"
        '
        'LabelGain
        '
        Me.LabelGain.AutoSize = True
        Me.LabelGain.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelGain.Location = New System.Drawing.Point(203, 50)
        Me.LabelGain.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelGain.Name = "LabelGain"
        Me.LabelGain.Size = New System.Drawing.Size(44, 20)
        Me.LabelGain.TabIndex = 44
        Me.LabelGain.Text = "Gain"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(47, 140)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(61, 20)
        Me.Label13.TabIndex = 40
        Me.Label13.Text = "Gain B"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(47, 94)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(62, 20)
        Me.Label14.TabIndex = 39
        Me.Label14.Text = "Gain G"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(47, 48)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(61, 20)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "Gain R"
        '
        'TabPage12
        '
        Me.TabPage12.BackColor = System.Drawing.Color.WhiteSmoke
        Me.TabPage12.Controls.Add(Me.HTML)
        Me.TabPage12.Controls.Add(Me.SessionLocation)
        Me.TabPage12.Controls.Add(Me.Label33)
        Me.TabPage12.Controls.Add(Me.ConfirmAction)
        Me.TabPage12.Controls.Add(Me.ContinueSession)
        Me.TabPage12.Controls.Add(Me.NewSession)
        Me.TabPage12.Controls.Add(Me.SessionName)
        Me.TabPage12.Controls.Add(Me.Button35)
        Me.TabPage12.Controls.Add(Me.Label_html_dir)
        Me.TabPage12.Controls.Add(Me.CheckBox_no_html)
        Me.TabPage12.Controls.Add(Me.CheckBox_incognito)
        Me.TabPage12.Controls.Add(Me.Button_experiment)
        Me.TabPage12.Controls.Add(Me.Button_OpenHtml)
        Me.TabPage12.Location = New System.Drawing.Point(4, 28)
        Me.TabPage12.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(919, 427)
        Me.TabPage12.TabIndex = 2
        Me.TabPage12.Text = "HTML"
        '
        'HTML
        '
        Me.HTML.AutoSize = True
        Me.HTML.Location = New System.Drawing.Point(163, 118)
        Me.HTML.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.HTML.Name = "HTML"
        Me.HTML.Size = New System.Drawing.Size(72, 20)
        Me.HTML.TabIndex = 63
        Me.HTML.Text = "Include"
        Me.HTML.UseVisualStyleBackColor = True
        '
        'SessionLocation
        '
        Me.SessionLocation.Location = New System.Drawing.Point(163, 87)
        Me.SessionLocation.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.SessionLocation.Multiline = True
        Me.SessionLocation.Name = "SessionLocation"
        Me.SessionLocation.Size = New System.Drawing.Size(457, 24)
        Me.SessionLocation.TabIndex = 62
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(159, 70)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(113, 16)
        Me.Label33.TabIndex = 61
        Me.Label33.Text = "Session Location:"
        '
        'ConfirmAction
        '
        Me.ConfirmAction.Location = New System.Drawing.Point(20, 117)
        Me.ConfirmAction.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ConfirmAction.Name = "ConfirmAction"
        Me.ConfirmAction.Size = New System.Drawing.Size(75, 23)
        Me.ConfirmAction.TabIndex = 60
        Me.ConfirmAction.Text = "Confirm"
        Me.ConfirmAction.UseVisualStyleBackColor = True
        '
        'ContinueSession
        '
        Me.ContinueSession.AutoSize = True
        Me.ContinueSession.Location = New System.Drawing.Point(20, 94)
        Me.ContinueSession.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ContinueSession.Name = "ContinueSession"
        Me.ContinueSession.Size = New System.Drawing.Size(132, 20)
        Me.ContinueSession.TabIndex = 59
        Me.ContinueSession.TabStop = True
        Me.ContinueSession.Text = "Continue Session"
        Me.ContinueSession.UseVisualStyleBackColor = True
        '
        'NewSession
        '
        Me.NewSession.AutoSize = True
        Me.NewSession.Location = New System.Drawing.Point(20, 70)
        Me.NewSession.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.NewSession.Name = "NewSession"
        Me.NewSession.Size = New System.Drawing.Size(107, 20)
        Me.NewSession.TabIndex = 58
        Me.NewSession.TabStop = True
        Me.NewSession.Text = "New Session"
        Me.NewSession.UseVisualStyleBackColor = True
        '
        'SessionName
        '
        Me.SessionName.AutoSize = True
        Me.SessionName.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SessionName.Location = New System.Drawing.Point(13, 16)
        Me.SessionName.Name = "SessionName"
        Me.SessionName.Size = New System.Drawing.Size(239, 39)
        Me.SessionName.TabIndex = 57
        Me.SessionName.Text = "Session Name"
        '
        'Button35
        '
        Me.Button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button35.ForeColor = System.Drawing.SystemColors.Control
        Me.Button35.Location = New System.Drawing.Point(37, 22)
        Me.Button35.Margin = New System.Windows.Forms.Padding(0)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(29, 30)
        Me.Button35.TabIndex = 56
        Me.Button35.UseVisualStyleBackColor = True
        '
        'Label_html_dir
        '
        Me.Label_html_dir.AutoSize = True
        Me.Label_html_dir.Location = New System.Drawing.Point(21, 98)
        Me.Label_html_dir.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_html_dir.Name = "Label_html_dir"
        Me.Label_html_dir.Size = New System.Drawing.Size(92, 16)
        Me.Label_html_dir.TabIndex = 36
        Me.Label_html_dir.Text = "HTML Folder :"
        '
        'CheckBox_no_html
        '
        Me.CheckBox_no_html.AutoSize = True
        Me.CheckBox_no_html.Location = New System.Drawing.Point(20, 254)
        Me.CheckBox_no_html.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox_no_html.Name = "CheckBox_no_html"
        Me.CheckBox_no_html.Size = New System.Drawing.Size(144, 20)
        Me.CheckBox_no_html.TabIndex = 35
        Me.CheckBox_no_html.Text = "Don't write to HTML"
        Me.CheckBox_no_html.UseVisualStyleBackColor = True
        '
        'CheckBox_incognito
        '
        Me.CheckBox_incognito.AutoSize = True
        Me.CheckBox_incognito.Location = New System.Drawing.Point(20, 226)
        Me.CheckBox_incognito.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox_incognito.Name = "CheckBox_incognito"
        Me.CheckBox_incognito.Size = New System.Drawing.Size(158, 20)
        Me.CheckBox_incognito.TabIndex = 34
        Me.CheckBox_incognito.Text = "Get hide from Richard"
        Me.CheckBox_incognito.UseVisualStyleBackColor = True
        '
        'Button_experiment
        '
        Me.Button_experiment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button_experiment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_experiment.ForeColor = System.Drawing.SystemColors.Control
        Me.Button_experiment.Location = New System.Drawing.Point(9, 27)
        Me.Button_experiment.Margin = New System.Windows.Forms.Padding(0)
        Me.Button_experiment.Name = "Button_experiment"
        Me.Button_experiment.Size = New System.Drawing.Size(40, 37)
        Me.Button_experiment.TabIndex = 45
        Me.Button_experiment.UseVisualStyleBackColor = True
        '
        'Button_OpenHtml
        '
        Me.Button_OpenHtml.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button_OpenHtml.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_OpenHtml.ForeColor = System.Drawing.SystemColors.Control
        Me.Button_OpenHtml.Location = New System.Drawing.Point(67, 27)
        Me.Button_OpenHtml.Margin = New System.Windows.Forms.Padding(0)
        Me.Button_OpenHtml.Name = "Button_OpenHtml"
        Me.Button_OpenHtml.Size = New System.Drawing.Size(40, 37)
        Me.Button_OpenHtml.TabIndex = 48
        Me.Button_OpenHtml.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Button28)
        Me.TabPage2.Controls.Add(Me.Label26)
        Me.TabPage2.Controls.Add(Me.CheckBox3)
        Me.TabPage2.Controls.Add(Me.Button13)
        Me.TabPage2.Controls.Add(Me.Button12)
        Me.TabPage2.Controls.Add(Me.Button8)
        Me.TabPage2.Controls.Add(Me.TextBox_PreviewFocus)
        Me.TabPage2.Controls.Add(Me.TextBox_PrevieEXp)
        Me.TabPage2.Location = New System.Drawing.Point(4, 28)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(919, 427)
        Me.TabPage2.TabIndex = 6
        Me.TabPage2.Text = "Preview"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(576, 36)
        Me.Button28.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(100, 28)
        Me.Button28.TabIndex = 141
        Me.Button28.Text = "Calibrate"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(235, 39)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(64, 16)
        Me.Label26.TabIndex = 140
        Me.Label26.Text = "Exposure"
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(311, 113)
        Me.CheckBox3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(55, 20)
        Me.CheckBox3.TabIndex = 139
        Me.CheckBox3.Text = "LED"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(55, 108)
        Me.Button13.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(159, 28)
        Me.Button13.TabIndex = 4
        Me.Button13.Text = "Go Back"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(55, 73)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(159, 28)
        Me.Button12.TabIndex = 3
        Me.Button12.Text = "Capture"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(55, 37)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(159, 28)
        Me.Button8.TabIndex = 2
        Me.Button8.Text = "Move to Preview"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'TextBox_PreviewFocus
        '
        Me.TextBox_PreviewFocus.Location = New System.Drawing.Point(311, 73)
        Me.TextBox_PreviewFocus.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_PreviewFocus.Name = "TextBox_PreviewFocus"
        Me.TextBox_PreviewFocus.Size = New System.Drawing.Size(95, 22)
        Me.TextBox_PreviewFocus.TabIndex = 1
        Me.TextBox_PreviewFocus.Text = "100"
        '
        'TextBox_PrevieEXp
        '
        Me.TextBox_PrevieEXp.Location = New System.Drawing.Point(311, 34)
        Me.TextBox_PrevieEXp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox_PrevieEXp.Name = "TextBox_PrevieEXp"
        Me.TextBox_PrevieEXp.Size = New System.Drawing.Size(95, 22)
        Me.TextBox_PrevieEXp.TabIndex = 0
        Me.TextBox_PrevieEXp.Text = "-11"
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Button2)
        Me.TabPage5.Controls.Add(Me.Button17)
        Me.TabPage5.Location = New System.Drawing.Point(4, 28)
        Me.TabPage5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(919, 427)
        Me.TabPage5.TabIndex = 7
        Me.TabPage5.Text = "Auto Focus"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(249, 36)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(161, 28)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Move to next  dots"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(141, 36)
        Me.Button17.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(100, 28)
        Me.Button17.TabIndex = 6
        Me.Button17.Text = "Calibrate"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.TextBox19)
        Me.TabPage9.Controls.Add(Me.TextBox20)
        Me.TabPage9.Controls.Add(Me.Button27)
        Me.TabPage9.Controls.Add(Me.Button26)
        Me.TabPage9.Location = New System.Drawing.Point(4, 28)
        Me.TabPage9.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(919, 427)
        Me.TabPage9.TabIndex = 9
        Me.TabPage9.Text = "Triangulation"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'TextBox19
        '
        Me.TextBox19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox19.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox19.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox19.Location = New System.Drawing.Point(339, 39)
        Me.TextBox19.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(75, 25)
        Me.TextBox19.TabIndex = 154
        Me.TextBox19.Text = "10"
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox20
        '
        Me.TextBox20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox20.Font = New System.Drawing.Font("Calibri", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox20.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.TextBox20.Location = New System.Drawing.Point(256, 39)
        Me.TextBox20.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(75, 25)
        Me.TextBox20.TabIndex = 153
        Me.TextBox20.Text = "10"
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(148, 39)
        Me.Button27.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(100, 28)
        Me.Button27.TabIndex = 152
        Me.Button27.Text = "Scan"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(40, 39)
        Me.Button26.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(100, 28)
        Me.Button26.TabIndex = 151
        Me.Button26.Text = "Button26"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.Button31)
        Me.TabPage11.Controls.Add(Me.Button34)
        Me.TabPage11.Controls.Add(Me.TextBox23)
        Me.TabPage11.Controls.Add(Me.TextBox22)
        Me.TabPage11.Controls.Add(Me.TextBox21)
        Me.TabPage11.Controls.Add(Me.Label24)
        Me.TabPage11.Controls.Add(Me.Label23)
        Me.TabPage11.Controls.Add(Me.Label22)
        Me.TabPage11.Controls.Add(Me.GroupBox1)
        Me.TabPage11.Location = New System.Drawing.Point(4, 28)
        Me.TabPage11.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TabPage11.Size = New System.Drawing.Size(919, 427)
        Me.TabPage11.TabIndex = 10
        Me.TabPage11.Text = "EDOF SandBoX"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(576, 240)
        Me.Button31.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(207, 28)
        Me.Button31.TabIndex = 162
        Me.Button31.Text = "Export raw files "
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(576, 197)
        Me.Button34.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(207, 28)
        Me.Button34.TabIndex = 161
        Me.Button34.Text = "Estimate single field Zprofile"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(480, 277)
        Me.TextBox23.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(47, 22)
        Me.TextBox23.TabIndex = 160
        Me.TextBox23.Text = "4"
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(480, 236)
        Me.TextBox22.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(47, 22)
        Me.TextBox22.TabIndex = 158
        Me.TextBox22.Text = "10"
        Me.TextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(480, 201)
        Me.TextBox21.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(47, 22)
        Me.TextBox21.TabIndex = 155
        Me.TextBox21.Text = "100"
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(339, 277)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(42, 16)
        Me.Label24.TabIndex = 159
        Me.Label24.Text = "Scale"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(339, 240)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(91, 16)
        Me.Label23.TabIndex = 157
        Me.Label23.Text = "Step size (um)"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(339, 204)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(80, 16)
        Me.Label22.TabIndex = 156
        Me.Label22.Text = "Range  (um)"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CheckBox1)
        Me.GroupBox1.Controls.Add(Me.Button22)
        Me.GroupBox1.Controls.Add(Me.Button18)
        Me.GroupBox1.Location = New System.Drawing.Point(61, 38)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(309, 75)
        Me.GroupBox1.TabIndex = 149
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Not RL Safe"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(231, 32)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(46, 20)
        Me.CheckBox1.TabIndex = 150
        Me.CheckBox1.Text = "LD"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(21, 27)
        Me.Button22.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(100, 28)
        Me.Button22.TabIndex = 2
        Me.Button22.Text = "Super"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(127, 27)
        Me.Button18.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(100, 28)
        Me.Button18.TabIndex = 0
        Me.Button18.Text = "Duper"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'CheckBox_EDOF
        '
        Me.CheckBox_EDOF.AutoSize = True
        Me.CheckBox_EDOF.Checked = True
        Me.CheckBox_EDOF.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_EDOF.Location = New System.Drawing.Point(567, 21)
        Me.CheckBox_EDOF.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox_EDOF.Name = "CheckBox_EDOF"
        Me.CheckBox_EDOF.Size = New System.Drawing.Size(66, 20)
        Me.CheckBox_EDOF.TabIndex = 150
        Me.CheckBox_EDOF.Text = "EDOF"
        Me.CheckBox_EDOF.UseVisualStyleBackColor = True
        '
        'PictureBox0
        '
        Me.PictureBox0.BackColor = System.Drawing.Color.Black
        Me.PictureBox0.Location = New System.Drawing.Point(49, 58)
        Me.PictureBox0.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox0.Name = "PictureBox0"
        Me.PictureBox0.Size = New System.Drawing.Size(1365, 1260)
        Me.PictureBox0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox0.TabIndex = 153
        Me.PictureBox0.TabStop = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(2387, 10)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(100, 38)
        Me.Button4.TabIndex = 154
        Me.Button4.Text = "stitch"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(269, 12)
        Me.Button30.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(83, 36)
        Me.Button30.TabIndex = 157
        Me.Button30.Text = "Auto Exp"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Button_Scan2
        '
        Me.Button_Scan2.Location = New System.Drawing.Point(451, 12)
        Me.Button_Scan2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Button_Scan2.Name = "Button_Scan2"
        Me.Button_Scan2.Size = New System.Drawing.Size(101, 36)
        Me.Button_Scan2.TabIndex = 159
        Me.Button_Scan2.Text = "Scan"
        Me.Button_Scan2.UseVisualStyleBackColor = True
        '
        'ComboBox_Objetives
        '
        Me.ComboBox_Objetives.FormattingEnabled = True
        Me.ComboBox_Objetives.Items.AddRange(New Object() {"10 X", "20 X"})
        Me.ComboBox_Objetives.Location = New System.Drawing.Point(1468, 18)
        Me.ComboBox_Objetives.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ComboBox_Objetives.Name = "ComboBox_Objetives"
        Me.ComboBox_Objetives.Size = New System.Drawing.Size(104, 24)
        Me.ComboBox_Objetives.TabIndex = 160
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1844, 846)
        Me.Controls.Add(Me.ComboBox_Objetives)
        Me.Controls.Add(Me.Button_Scan2)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.PictureBox0)
        Me.Controls.Add(Me.CheckBox_EDOF)
        Me.Controls.Add(Me.TabControl2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox_exposure)
        Me.Controls.Add(Me.CheckBoxLED)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.TextBoxY)
        Me.Controls.Add(Me.TextBoxX)
        Me.Controls.Add(Me.Pbar)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.RadioButton_zoom_out)
        Me.Controls.Add(Me.RadioButton_zoom_in)
        Me.Controls.Add(Me.Button_adjustBrightness)
        Me.Controls.Add(Me.Button_Brightfield_Acquire)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Form1"
        Me.Text = "Darius"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox3.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox_Preview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabControl_Settings.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage13.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox0, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button_Home As Button
    Friend WithEvents Button_bottom As Button
    Friend WithEvents Button_top As Button
    Friend WithEvents Button_left As Button
    Friend WithEvents Button_right As Button
    Friend WithEvents Button_adjustBrightness As Button
    Friend WithEvents RadioButton_zoom_out As RadioButton
    Friend WithEvents RadioButton_zoom_in As RadioButton
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents Button_Brightfield_Acquire As Button
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents PictureBox_Preview As PictureBox
    Friend WithEvents Pbar As ProgressBar
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents Button1 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents CheckBoxLED As CheckBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Button_GIMP As Button
    Friend WithEvents TextBox_exposure As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents TextBoxY As TextBox
    Friend WithEvents TextBoxX As TextBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Button_Luigi As Button
    Friend WithEvents TabControl2 As TabControl
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents Button_Sedeen As Button
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents CheckBox_EDOF As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents RadioButton_Zprofile As RadioButton
    Friend WithEvents RadioButton_Preview As RadioButton
    Friend WithEvents PictureBox0 As PictureBox
    Friend WithEvents Button4 As Button
    Friend WithEvents Button30 As Button
    Friend WithEvents TabControl_Settings As TabControl
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents Button20 As Button
    Friend WithEvents Button21 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox_FOVY As TextBox
    Friend WithEvents TextBox_FOVX As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button7 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents Label21 As Label
    Friend WithEvents Button25 As Button
    Friend WithEvents Button24 As Button
    Friend WithEvents Button23 As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TextBox_BlueOffset As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBoxGC As TextBox
    Friend WithEvents TextBoxGY As TextBox
    Friend WithEvents TextBoxGain As TextBox
    Friend WithEvents TextBox_GainB As TextBox
    Friend WithEvents TextBox_GainG As TextBox
    Friend WithEvents TextBox_GainR As TextBox
    Friend WithEvents Label27 As Label
    Friend WithEvents Button32 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents LabelGC As Label
    Friend WithEvents LabelGY As Label
    Friend WithEvents LabelGain As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents Label_html_dir As Label
    Friend WithEvents CheckBox_no_html As CheckBox
    Friend WithEvents CheckBox_incognito As CheckBox
    Friend WithEvents Button_experiment As Button
    Friend WithEvents Button_OpenHtml As Button
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label26 As Label
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents TextBox_PreviewFocus As TextBox
    Friend WithEvents TextBox_PrevieEXp As TextBox
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents Button2 As Button
    Friend WithEvents Button17 As Button
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents Button27 As Button
    Friend WithEvents Button26 As Button
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents Button34 As Button
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents Button22 As Button
    Friend WithEvents Button18 As Button
    Friend WithEvents CheckBox_PredictiveFocous As CheckBox
    Friend WithEvents Button28 As Button
    Friend WithEvents Button_Scan2 As Button
    Friend WithEvents Button_TurnonGain As Button
    Friend WithEvents Button_turnOffGain As Button
    Friend WithEvents Button31 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents Button29 As Button
    Friend WithEvents TextBox_RichardScale As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents ComboBox_Objetives As ComboBox

    Friend WithEvents HTML As CheckBox

    Friend WithEvents SessionLocation As TextBox

    Friend WithEvents Label33 As Label

    Friend WithEvents ConfirmAction As Button

    Friend WithEvents ContinueSession As RadioButton

    Friend WithEvents NewSession As RadioButton

    Friend WithEvents SessionName As Label

    Friend WithEvents Button35 As Button
End Class
